package com.example.groupassignmentreal;

import android.net.Uri;

public class MLKitResult {

    private String filename;
    private String reader;
    private String result;
    private Uri imageUri;

    public MLKitResult(String reader, String result, Uri imageUri) {
        this.reader = reader;
        this.result = result;
        this.imageUri = imageUri;
    }

    public MLKitResult(String filename, String reader, String result, Uri imageUri) {
        this.filename = filename;
        this.reader = reader;
        this.result = result;
        this.imageUri = imageUri;
    }

    public String getFilename() {
        return filename;
    }

    public void setFilename(String filename) {
        this.filename = filename;
    }

    public String getReader() {
        return reader;
    }

    public void setReader(String reader) {
        this.reader = reader;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public Uri getImageUri() {
        return imageUri;
    }

    public void setImageUri(Uri imageUri) {
        this.imageUri = imageUri;
    }
}
