package com.example.groupassignmentreal;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;

public class ReaderActivity extends AppCompatActivity {

    public static final String DB_URL =
            "https://group-assignment-f17b2-default-rtdb.asia-southeast1.firebasedatabase.app";

    private TextView textViewReader;
    private EditText editTextResult;
    private ImageView imageViewActivity5;

    private String reader;
    private String filename;
    private String uriString;
    private String imagePath; // local file path; non-empty when editing an existing item
    private boolean existing; // true when launched from Activity 7 (Edit)

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_editresult);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        textViewReader = findViewById(R.id.textViewReader);
        editTextResult = findViewById(R.id.editTextResult);
        imageViewActivity5 = findViewById(R.id.imageViewActivity5);

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            reader = extras.getString("reader", "");
            String result = extras.getString("result", "");
            filename = extras.getString("filename", "");
            uriString = extras.getString("uri", "");
            imagePath = extras.getString("imagePath", "");
            existing = extras.getBoolean("existing", false);

            textViewReader.setText(reader);
            editTextResult.setText(result);

            // Prefer the saved local file path (existing item) over the temporary content URI.
            if (imagePath != null && !imagePath.isEmpty()) {
                imageViewActivity5.setImageURI(Uri.fromFile(new File(imagePath)));
            } else if (uriString != null && !uriString.isEmpty()) {
                imageViewActivity5.setImageURI(Uri.parse(uriString));
            }
        }
    }

    public void saveResult(View view) {
        String editedText = editTextResult.getText().toString();

        if (filename == null || filename.isEmpty()) {
            Toast.makeText(this, "Missing filename, cannot save.", Toast.LENGTH_SHORT).show();
            return;
        }

        // For NEW items (coming from Activity 2), copy the image into internal storage
        // with a unique filename so it survives after the gallery/camera URI expires.
        // For EXISTING items (coming from Activity 7 Edit), keep the existing imagePath.
        String storedImagePath = imagePath;
        if (!existing) {
            try {
                File outFile = new File(getFilesDir(), filename + ".jpg");
                Uri src = Uri.parse(uriString);
                try (InputStream in = getContentResolver().openInputStream(src);
                     OutputStream out = new FileOutputStream(outFile)) {
                    if (in == null) throw new Exception("Cannot open source image.");
                    byte[] buf = new byte[8192];
                    int n;
                    while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                }
                storedImagePath = outFile.getAbsolutePath();
            } catch (Exception e) {
                Toast.makeText(this, "Image save failed: " + e.getMessage(),
                        Toast.LENGTH_LONG).show();
                return;
            }
        }

        DatabaseReference ref = FirebaseDatabase
                .getInstance(DB_URL)
                .getReference("Storage")
                .child(filename);

        if (existing) {
            // Update only the editable text fields on the existing record.
            Map<String, Object> updates = new HashMap<>();
            updates.put("reader", reader);
            updates.put("text", editedText);
            ref.updateChildren(updates)
                    .addOnSuccessListener(unused -> goToList())
                    .addOnFailureListener(e -> Toast.makeText(ReaderActivity.this,
                            "Save failed: " + e.getMessage(), Toast.LENGTH_LONG).show());
        } else {
            Map<String, Object> entry = new HashMap<>();
            entry.put("filename", filename);
            entry.put("reader", reader);
            entry.put("text", editedText);
            entry.put("imagePath", storedImagePath);
            entry.put("imageUri", uriString); // kept for backward compatibility
            ref.setValue(entry)
                    .addOnSuccessListener(unused -> goToList())
                    .addOnFailureListener(e -> Toast.makeText(ReaderActivity.this,
                            "Save failed: " + e.getMessage(), Toast.LENGTH_LONG).show());
        }
    }

    private void goToList() {
        Toast.makeText(ReaderActivity.this, "Saved", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(ReaderActivity.this, ListActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(intent);
        finish();
    }
}
