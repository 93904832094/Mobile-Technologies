package com.example.groupassignmentreal;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class ListActivity extends AppCompatActivity {

    private final List<MLKitResult> items = new ArrayList<>();
    private MLKitAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_list);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        ListView listView = findViewById(R.id.listViewItems);
        adapter = new MLKitAdapter(this, R.layout.list_item, items);
        listView.setAdapter(adapter);

        DatabaseReference ref = FirebaseDatabase
                .getInstance(ReaderActivity.DB_URL)
                .getReference("Storage");

        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                items.clear();
                for (DataSnapshot child : snapshot.getChildren()) {
                    String filename = child.child("filename").getValue(String.class);
                    String reader = child.child("reader").getValue(String.class);
                    String text = child.child("text").getValue(String.class);
                    String imagePath = child.child("imagePath").getValue(String.class);
                    String imageUri = child.child("imageUri").getValue(String.class);

                    Uri displayUri = null;
                    if (imagePath != null && !imagePath.isEmpty()) {
                        displayUri = Uri.fromFile(new File(imagePath));
                    } else if (imageUri != null && !imageUri.isEmpty()) {
                        displayUri = Uri.parse(imageUri);
                    }

                    items.add(new MLKitResult(filename, reader, text, displayUri));
                }
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(ListActivity.this,
                        "Failed to load: " + error.getMessage(),
                        Toast.LENGTH_LONG).show();
            }
        });

        listView.setOnItemClickListener((parent, view, position, id) -> {
            MLKitResult item = items.get(position);
            Intent intent = new Intent(ListActivity.this, ItemActivity.class);
            intent.putExtra("filename", item.getFilename());
            intent.putExtra("reader", item.getReader());
            intent.putExtra("text", item.getResult());
            intent.putExtra("imagePath",
                    item.getImageUri() != null ? item.getImageUri().getPath() : "");
            startActivity(intent);
        });

        Button buttonAdd = findViewById(R.id.buttonAdd);
        buttonAdd.setOnClickListener(v -> {
            Intent intent = new Intent(ListActivity.this, MainActivity.class);
            startActivity(intent);
        });
    }
}
