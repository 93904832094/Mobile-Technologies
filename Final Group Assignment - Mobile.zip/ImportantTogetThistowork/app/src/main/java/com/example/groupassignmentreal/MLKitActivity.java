package com.example.groupassignmentreal;

import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.Html;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.mlkit.vision.barcode.BarcodeScanner;
import com.google.mlkit.vision.barcode.BarcodeScannerOptions;
import com.google.mlkit.vision.barcode.BarcodeScanning;
import com.google.mlkit.vision.barcode.common.Barcode;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.label.ImageLabel;
import com.google.mlkit.vision.label.ImageLabeler;
import com.google.mlkit.vision.label.ImageLabeling;
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Locale;

public class MLKitActivity extends AppCompatActivity {

    public static final String EXTRA_READER_TYPE = "readerType";
    public static final String READER_BARCODE = "BARCODE";
    public static final String READER_CONTENT = "CONTENT";
    public static final String READER_TEXT = "TEXT";

    private static final int REQUEST_PERMISSION = 3000;

    private Uri imageFileUri;
    private ImageView imageView;
    private TextView textViewTitle;
    private TextView textViewOutput;
    private String readerType = READER_BARCODE;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_mlkit);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        imageView = findViewById(R.id.imageViewMLKit);
        textViewTitle = findViewById(R.id.textViewTitle);
        textViewOutput = findViewById(R.id.textViewResult);

        Bundle extras = getIntent().getExtras();
        if (extras != null && extras.getString(EXTRA_READER_TYPE) != null) {
            readerType = extras.getString(EXTRA_READER_TYPE);
        }

        // Initial state per rubric: title is "Get Image from Camera or Gallery",
        // result text is the instruction. Both update after analysis.
        textViewTitle.setText("Get Image from Camera or Gallery");
        textViewOutput.setText("Tap OPEN CAMERA or LOAD IMAGE to get an image for analysis");
        imageView.setImageResource(getPlaceholderImage(readerType));
    }

    private int getPlaceholderImage(String type) {
        switch (type) {
            case READER_CONTENT:
                return R.mipmap.contentreader_foreground;
            case READER_TEXT:
                return R.mipmap.textreader_foreground;
            case READER_BARCODE:
            default:
                return R.mipmap.barcodereader_foreground;
        }
    }

    private String getReaderName(String type) {
        switch (type) {
            case READER_CONTENT:
                return "Content Reader";
            case READER_TEXT:
                return "Text Reader";
            case READER_BARCODE:
            default:
                return "Barcode Reader";
        }
    }

    private boolean checkPermission() {
        String permission = android.Manifest.permission.CAMERA;
        boolean grantCamera = ContextCompat.checkSelfPermission(this, permission)
                == PackageManager.PERMISSION_GRANTED;
        if (!grantCamera) {
            ActivityCompat.requestPermissions(this, new String[]{permission}, REQUEST_PERMISSION);
        }
        return grantCamera;
    }

    public void openCamera(View view) {
        if (!checkPermission()) return;
        Intent takePhotoIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        imageFileUri = getContentResolver().insert(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI, new ContentValues());
        takePhotoIntent.putExtra(MediaStore.EXTRA_OUTPUT, imageFileUri);
        activityResultLauncher.launch(takePhotoIntent);
    }

    public void loadImage(View view) {
        Intent galleryIntent = new Intent(Intent.ACTION_PICK,
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        activityResultLauncher.launch(galleryIntent);
    }

    public void openListView(View view) {
        if (imageFileUri == null) {
            Toast.makeText(this,
                    "Please open the camera or load an image first.",
                    Toast.LENGTH_SHORT).show();
            return;
        }
        String imageFilename = LocalDateTime.now().toString().replaceAll("\\D+", "");
        Intent intent = new Intent(MLKitActivity.this, ReaderActivity.class);
        intent.putExtra("reader", getReaderName(readerType));
        intent.putExtra("result", textViewOutput.getText().toString());
        intent.putExtra("filename", imageFilename);
        intent.putExtra("uri", imageFileUri.toString());
        startActivity(intent);
    }

    ActivityResultLauncher<Intent> activityResultLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    if (result.getResultCode() != RESULT_OK) return;
                    if (result.getData() != null && result.getData().getData() != null) {
                        imageFileUri = result.getData().getData();
                    }
                    if (imageFileUri == null) return;

                    imageView.setImageURI(imageFileUri);
                    textViewTitle.setText(getReaderName(readerType));
                    textViewOutput.setText("");

                    InputImage image = null;
                    try {
                        image = InputImage.fromFilePath(getBaseContext(), imageFileUri);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    if (image == null) return;

                    switch (readerType) {
                        case READER_CONTENT:
                            processImageFromContentReader(image);
                            break;
                        case READER_TEXT:
                            processImageFromTextReader(image);
                            break;
                        case READER_BARCODE:
                        default:
                            processImageFromBarcodeReader(image);
                            break;
                    }
                }
            });

    public void processImageFromBarcodeReader(InputImage image) {
        BarcodeScannerOptions options = new BarcodeScannerOptions.Builder()
                .setBarcodeFormats(Barcode.FORMAT_ALL_FORMATS).build();
        BarcodeScanner scanner = BarcodeScanning.getClient(options);
        scanner.process(image)
                .addOnSuccessListener(new OnSuccessListener<List<Barcode>>() {
                    @Override
                    public void onSuccess(List<Barcode> barcodes) {
                        textViewOutput.append(Html.fromHtml(
                                "<font color='navy'><b>Detected barcode:</b></font><br>",
                                Html.FROM_HTML_MODE_LEGACY));
                        String resultStr = "";
                        for (Barcode barcode : barcodes) {
                            resultStr = barcode.getRawValue();
                            textViewOutput.append(resultStr + "\n");
                        }
                        if (resultStr.length() < 2) {
                            textViewOutput.append(" Barcode not found.\n");
                        }
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        textViewOutput.setText("Failed");
                    }
                });
    }

    public void processImageFromContentReader(InputImage image) {
        ImageLabeler labeler = ImageLabeling.getClient(ImageLabelerOptions.DEFAULT_OPTIONS);
        labeler.process(image)
                .addOnSuccessListener(new OnSuccessListener<List<ImageLabel>>() {
                    @Override
                    public void onSuccess(List<ImageLabel> labels) {
                        if (labels.isEmpty()) {
                            textViewOutput.append("Nothing found in the image\n");
                            return;
                        }
                        textViewOutput.append(Html.fromHtml(
                                "<font color='navy'><b>Recognised image content:</b></font><br>",
                                Html.FROM_HTML_MODE_LEGACY));
                        int counter = 1;
                        for (ImageLabel label : labels) {
                            String result = label.getText();
                            float confidence = label.getConfidence();
                            textViewOutput.append(String.format(Locale.getDefault(),
                                    " %d. %s (%.2f%% confidence)\n",
                                    counter, result, confidence * 100.0f));
                            counter++;
                        }
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        textViewOutput.setText("Failed: " + e.getMessage());
                    }
                });
    }

    public void processImageFromTextReader(InputImage image) {
        TextRecognizer recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        recognizer.process(image)
                .addOnSuccessListener(new OnSuccessListener<Text>() {
                    @Override
                    public void onSuccess(Text visionText) {
                        textViewOutput.append(Html.fromHtml(
                                "<font color='navy'><b>Extracted text:</b></font><br>",
                                Html.FROM_HTML_MODE_LEGACY));
                        String result = visionText.getText();
                        if (result.length() > 1)
                            textViewOutput.append(" " + result + "\n");
                        else
                            textViewOutput.append(" No text found.\n");
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        textViewOutput.setText("Failed");
                    }
                });
    }
}
