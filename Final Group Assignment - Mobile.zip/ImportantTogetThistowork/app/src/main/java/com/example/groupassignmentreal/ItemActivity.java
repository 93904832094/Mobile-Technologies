package com.example.groupassignmentreal;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.io.File;

public class ItemActivity extends AppCompatActivity {

    private String filename;
    private String reader;
    private String text;
    private String imagePath;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_item);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        TextView textViewReader = findViewById(R.id.textViewReader);
        TextView textViewResult = findViewById(R.id.textViewResult);
        ImageView imageView = findViewById(R.id.imageView);
        Button buttonEdit = findViewById(R.id.buttonEdit);
        Button buttonDelete = findViewById(R.id.buttonDelete);
        Button buttonCancel = findViewById(R.id.buttonCancel);

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            filename = extras.getString("filename", "");
            reader = extras.getString("reader", "");
            text = extras.getString("text", "");
            imagePath = extras.getString("imagePath", "");
        }

        textViewReader.setText(reader);
        textViewResult.setText(text);
        if (imagePath != null && !imagePath.isEmpty()) {
            File f = new File(imagePath);
            if (f.exists()) {
                imageView.setImageURI(Uri.fromFile(f));
            }
        }

        buttonEdit.setOnClickListener(v -> {
            Intent intent = new Intent(ItemActivity.this, ReaderActivity.class);
            intent.putExtra("filename", filename);
            intent.putExtra("reader", reader);
            intent.putExtra("result", text);
            intent.putExtra("imagePath", imagePath);
            intent.putExtra("existing", true);
            startActivity(intent);
            finish();
        });

        buttonDelete.setOnClickListener(v -> {
            if (filename == null || filename.isEmpty()) {
                Toast.makeText(this, "Missing filename, cannot delete.",
                        Toast.LENGTH_SHORT).show();
                return;
            }
            DatabaseReference ref = FirebaseDatabase
                    .getInstance(ReaderActivity.DB_URL)
                    .getReference("Storage")
                    .child(filename);
            ref.removeValue()
                    .addOnSuccessListener(unused -> {
                        // Best-effort: delete the local image file too.
                        if (imagePath != null && !imagePath.isEmpty()) {
                            File f = new File(imagePath);
                            if (f.exists()) f.delete();
                        }
                        Toast.makeText(ItemActivity.this, "Deleted",
                                Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(ItemActivity.this, ListActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP
                                | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                        startActivity(intent);
                        finish();
                    })
                    .addOnFailureListener(e -> Toast.makeText(ItemActivity.this,
                            "Delete failed: " + e.getMessage(),
                            Toast.LENGTH_LONG).show());
        });

        buttonCancel.setOnClickListener(v -> {
            Intent intent = new Intent(ItemActivity.this, ListActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP
                    | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(intent);
            finish();
        });
    }
}
