package com.example.groupassignmentreal;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });


        ImageButton buttonBarcode = findViewById(R.id.buttonBarcode);
        buttonBarcode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, MLKitActivity.class);
                intent.putExtra(MLKitActivity.EXTRA_READER_TYPE, MLKitActivity.READER_BARCODE);
                startActivity(intent);
            }
        });

        ImageButton buttonContent = findViewById(R.id.buttonContent);
        buttonContent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, MLKitActivity.class);
                intent.putExtra(MLKitActivity.EXTRA_READER_TYPE, MLKitActivity.READER_CONTENT);
                startActivity(intent);
            }
        });

        ImageButton buttonTextReader = findViewById(R.id.buttonTextReader);
        buttonTextReader.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, MLKitActivity.class);
                intent.putExtra(MLKitActivity.EXTRA_READER_TYPE, MLKitActivity.READER_TEXT);
                startActivity(intent);
            }
        });

        Button buttonListImages = findViewById(R.id.buttonListImages);
        buttonListImages.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ListActivity.class);
                startActivity(intent);
            }
        });
    }
}
