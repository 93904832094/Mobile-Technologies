package com.example.groupassignmentreal;

import android.content.Context;
import android.graphics.Color;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class MLKitAdapter extends ArrayAdapter<MLKitResult> {

    // Match the rubric: grey for odd items, white for even items.
    private static final int COLOR_EVEN = Color.WHITE;
    private static final int COLOR_ODD = Color.parseColor("#EEEEEE");

    private List<MLKitResult> items = new ArrayList<>();

    public MLKitAdapter(@NonNull Context context, int resource, @NonNull List<MLKitResult> objects) {
        super(context, resource, objects);
        items = objects;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext())
                    .inflate(R.layout.list_item, parent, false);
        }
        MLKitResult item = items.get(position);

        ImageView icon = convertView.findViewById(R.id.imageViewListItem);
        Uri imageUri = item.getImageUri();
        if (imageUri != null) {
            // Local file URIs require setImageURI; if the file is gone, fall back to launcher icon.
            String path = imageUri.getPath();
            if (path != null && new File(path).exists()) {
                icon.setImageURI(imageUri);
            } else {
                icon.setImageResource(R.mipmap.ic_launcher);
            }
        } else {
            icon.setImageResource(R.mipmap.ic_launcher);
        }

        TextView textViewItem = convertView.findViewById(R.id.textViewItem);
        textViewItem.setText(item.getReader());

        // Alternating row backgrounds (even/odd by display position, 0 = first/even).
        convertView.setBackgroundColor((position % 2 == 0) ? COLOR_EVEN : COLOR_ODD);

        return convertView;
    }
}
